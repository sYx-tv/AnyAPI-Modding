# Local mods and Import DLL

An AnyAPI mod is a Windows x64 DLL exporting AnyAPI_ModInit. Use the starter project and current public headers. A generic DLL cannot be used as an AnyAPI mod.

In Mods, choose Import DLL, or place your DLL in AnyAPI and Modding/mods and select Refresh. The manager discovers local DLLs and disabled DLLs without a GitHub listing. Close the game before changing files. Local mods can be enabled, disabled and removed; their saved settings remain. Disabled files end in .dll.disabled. The native loader discovers lowercase .dll filenames, so import normalizes the extension.

Optional companion metadata: put ExampleMod.anymod.json beside ExampleMod.dll before importing. The manager stores imported details in its receipt. A manually placed companion file is also read while the DLL is enabled. Use this format:

```json
{"Name":"Example Mod","Version":"1.0.0","Description":"My own Anymaker mod.","MinimumApi":25}
```

MinimumApi is enforced. Omit the file if you only need discovery by DLL filename. Import inspects the PE export table without executing the DLL. This verifies its format, not its behavior, ABI implementation or safety.

Local mods show game compatibility as unverified. They may launch with a compatible AnyAPI, but the manager cannot prove they work on every game build. Test them in game. Local mods receive no automatic downloads or updates. Replace a local DLL through Import DLL; replacement keeps a backup. Publish a verified release and add it to catalog.json to provide library downloads and updates. The manager refreshes the catalog; no app code change is needed.

This manager controls DLL files, not mod dependency resolution or custom load order. The current native loader sorts DLL filenames. Settings and keybinds still require explicit registration with AnyHelpers; local discovery does not invent editable options.
