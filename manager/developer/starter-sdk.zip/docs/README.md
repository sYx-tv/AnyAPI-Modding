# Documentation

## Getting started

- [Player installation](../README.md#for-players)
- [Mod library and versions](mods/overview.md)
- [Build from source](development/building.md)
- [Create a DLL mod](development/first-mod.md)
- [Tutorial: a complete mod](development/mod-tutorial.md)
- [SDK headers and examples](../sdk/README.md)

## Mod guides

[AnyHelpers](mods/helpers.md) · [AnyInventory](mods/inventory.md) ·
[AnyStorage](mods/storage.md) · [AnyMap](mods/map.md) ([rendering](mods/map-rendering.md)) ·
[AnyGraphics](mods/graphics.md) · [AnyClock](mods/clock.md) ·
[AnyQuickWheel](mods/quick-wheel.md) · [AnyBalance](mods/balance.md) · [EngineSound](mods/engine-sound.md) · [AnyMirror](mods/mirror.md) · [GpsPart](mods/gps.md) · [ThirdPerson](mods/third-person.md) · [MCCode](mods/mccode.md) · [CustomGame](mods/custom-game.md) · [AnyMoto](mods/moto.md) ·
Prototypes: [AnyLights](mods/lights.md) · [AnyEngineParts](mods/engine-parts.md) ([turbos](mods/turbo.md), [rotary](mods/rotary.md), [dyno](mods/dyno.md)) · [AnyCombat](mods/combat.md)

## Developer reference

- [API services](api/README.md)
- [Scene lighting](scene-lighting.md) and [scene antialiasing internals](development/scene-antialiasing.md)
- [Experimental game-access SDK](../sdk/experimental/README.md) and [research references](sdk-reference/README.md)
- [Toolchain](development/toolchain.md) and [native inspection tools](../native/tools/README.md)
- [Publishing](development/publishing.md) and [catalog format](../manager/CATALOG_FORMAT.md)
- [Compatibility and validation](development/validation.md) and [porting to a new game build](development/game-updates.md)
- [Workspace handoff](development/workspace-handoff.md) for setting up a new machine
- [Contributing](../CONTRIBUTING.md)

The API reference describes the checked-in source, which can be ahead of the stable
catalog (see [validation](development/validation.md#development-source)). Published
manager resources are versioned separately; its bundled offline guide describes
API 0.27.0. [Release records](releases/README.md) keep historical evidence and
version numbers as they were at the time.
