# CustomGame

> CustomGame hooks game functions directly through the [experimental SDK](../../sdk/experimental/README.md),
> so it only activates on Anymaker 0.1.28 / Steam build 26277967 and turns itself off on any other build.
> CustomGame 0.1.0 requires AnyAPI 0.40.0 or newer on that build; install it from the manager.

CustomGame adds a **Custom Game** button to the New Game screen. It opens a settings page; **Start game** then
creates a normal Career, Creative (dome) or Sandbox world with your settings applied. The settings are saved with
that world and come back every time you load it.

## Using it

1. Click **New Game** in the main menu. The **Custom Game** button appears at the bottom middle of the screen.
2. Pick settings on the four tabs. Click **◀ / ▶** (or click the value: left click goes up, right click goes down).
   Changed settings are highlighted and each tab shows how many it has. **Esc** or **Back** closes the page.
3. Click **Start … game**. The world is created exactly like the matching native button, then the settings apply.

The page remembers the last settings you started with. The **Presets** tab saves and loads three slots.

| Tab | Setting | Range | Notes |
| --- | --- | --- | --- |
| General | Game mode | Career, Creative, Sandbox | |
| | Day cycle speed | Normal, Frozen, 0.25x to 8x | Normal keeps the game's rules (Sandbox time stands still) |
| | Start time | Game default, 00:00 to 23:00 | |
| | Starting loot tier | 1 to 5 | Set once when the world starts; finishing bunkers still raises it. Sandbox has no loot |
| | Map | Normal world, installed map packs | Shown when the CustomMap mod is installed. The pack is saved with the world |
| | Max players | 2 to 20 | The game's own limit is 6. Kept in place even when the multiplayer host screen sets its own count; above 6 is untested |
| Survival | Hunger, thirst, stamina drain, clothes soak speed | Off, 25% to 400% | Off means it never happens |
| | Stamina recovery, clothes dry speed | 25% to 400% | |
| | Breath underwater | 25% to 500% | Air and drowning time |
| | Bodies stay for, your lost body stays for | 25% to 800% | Shown in minutes |
| | Coldest / hottest temperature | −30 to +30 °C | Shifts the game's temperature limits |
| Danger | Zombies, creatures | Normal for the mode, On, Off | Normal follows the mode (Sandbox has none). On brings them to Sandbox too |
| | Zombie horde size | 0% to 300% | |
| | Max enemies around | 25% to 300% | Zombies, creatures and survivors |
| | Enemy sight range, enemy hearing range | 25% to 300% | Zombies, creatures and survivors |
| | No-spawn zone | 0% to 300% | The safe area around the world's starting point where enemies never spawn |
| | Survivor gun range | 50% to 300% | How far hostile survivors start shooting from (30 m normally). They still need to see you (sight range) |
| World | Loot amount | 25% to 500% | How often loot spots have something. Only places not yet visited are affected |
| | Weather | Normal, Always clear, cloudy, rain, storm, fog | |
| | Rain and snow density | 0% to 100% | Looks only |
| | Joint strength | 25% to 500%, Unbreakable | Hinges, latches, pins and rails |
| | Bunkers | Normal for the mode, On | On adds closed bunkers with loot to Sandbox (new worlds only); their zombies follow the Zombies setting |

## Multiplayer

Only the host needs CustomGame for the gameplay settings, the day cycle and the player limit. Weather and rain
density are worked out on each player's computer, so players without the mod see the game's normal weather.

Each player's game streams the map from its own files, so a world on a map pack needs that pack (and CustomGame
plus CustomMap) on every player's computer. The host sends the pack's name along with the weather; a player who
doesn't have it sees the normal world.

## Files

Everything lives in `<mods folder>\CustomGame\`:

- `worlds\<world seed>.cfg`: one file per custom world. Deleting it makes that world play with normal rules.
- `last.cfg` and `preset1.cfg` to `preset3.cfg`: the page's remembered settings and preset slots.

The files are plain `key=value` text. Hand edits snap to the nearest menu step.

## How it works

- The button and page are drawn with `anyapi.gpu_draw`. The mod knows the New Game screen is open because it hooks
  `frontend_ui._update_ui_new_game`, and **Start game** calls the game's own `frontend_ui._start_new_game` with the
  chosen mode.
- `server_scene._generate_new_game` binds the settings to the new world's seed. Each time the host runs a world
  (`server_scene.tick_loading` / `tick`), the file for its seed is applied, or the game's defaults are restored.
- Most settings scale the game's own tuning globals (hunger seconds, AI sight distance, loot capacity and so on)
  from the values read at start-up. The values are written to `anymaker_modding.log`.
- Day speed and start time drive the server time of day's replicated override, which every client already obeys.
  The override value also carries the weather lock and rain density in its lowest bits, so other players with
  CustomGame see the same weather. Weather is locked by hooking `weather_manager.get_weather_data`.
- The starting tier calls `server_scene.set_loot_level` once, on the first tick of a new world.
- Loot amount lowers or raises `g_loot_random_loot_capacity`. The game fills a loot spot when `rand(0, max(capacity,
  weight)) < weight`, so the mod divides the capacity by the chosen percentage.
- Sandbox switches its spawners off by checking the mode. When zombies or creatures are set to On in a Sandbox world,
  the mod runs those spawners (`creature_manager._tick_spawn`, tile spawn zones, sleeping actors, hordes) with the
  mode reading Career for the duration of the call.
- Tile loading (`environment_tile_task.integrate`) also skips spawn zones in Sandbox, so it is run the same way.
- Bunkers in Sandbox run `dungeon_manager.generate` and the bunker tiles' creature and loot generation as Career.
- The Map setting uses the CustomMap mod's `custommap.maps` service
  ([`custommap_v1.h`](../../sdk/include/custommap_v1.h)). The pack is selected when **Start game** is clicked and
  again before each world loads its tiles, and the normal world is selected for every other world.
- Every changed game value is written to `anymaker_modding.log` as `name default -> new` when a world starts.

## Known limits

- More than 6 players is untested: the game, its networking and its UI were built for 6.
- Sandbox players cannot be hurt and are revived at once, so zombies and creatures switched on there are harmless.
- Survival, loot and tier settings follow the game's own mode rules: Sandbox has no loot, and the Creative dome
  protects you while you are inside it.
- A world started with a higher tier skips the loot of the earlier tiers, the same way finishing bunkers does.
- With a fixed day speed or start time, a weather lock or a map, the game's developer time controls and
  AnyHelpers' ADMIN time setting are overridden in that world.
- The field offsets come from the 0.1.28 SDK reference; after a game update, re-check them as well as the
  bindings in `native/customgame_bindings.h`.
