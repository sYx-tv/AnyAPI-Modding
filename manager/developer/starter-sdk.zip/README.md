# Your first mod

1. Install Visual Studio with Desktop development with C++. Include CMake and the Windows SDK.
2. Choose Export starter SDK in this guide, then extract the ZIP.
3. Open the extracted folder in a developer PowerShell and build:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```

4. Close Anymaker. Copy build/Release/ExampleMod.dll into AnyAPI and Modding/mods inside the Anymaker Steam folder.
5. Install the compatible API with this manager, choose Play with mods, and check the framework log for example.hello / Loaded.

The starter is source only. It exports AnyAPI_ModInit, checks ABI 1 and writes a startup log. No game files or existing mod DLLs are included.

DLLs are loaded at game startup. Close and restart the game after rebuilding. Hot unloading is unsupported. Keep native game pointers out of the plugin ABI.

The included examples cover current native settings, inventory widgets, item lookup, session mode and screen translation. Each example names its required versioned service.
