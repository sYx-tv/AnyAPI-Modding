#include "anyapi_mod_v1.h"
static const AnyModHostV1* host;
extern "C" __declspec(dllexport) bool AnyAPI_ModInit(const AnyModHostV1* incoming, AnyModCallbacksV1* callbacks) {
    if (!incoming || !callbacks || incoming->abi != ANYAPI_MOD_ABI || incoming->struct_size != sizeof(AnyModHostV1)) return false;
    host = incoming; *callbacks = {}; callbacks->id = "example.hello";
    if (host->log) host->log(0, callbacks->id, "Loaded");
    return true;
}
